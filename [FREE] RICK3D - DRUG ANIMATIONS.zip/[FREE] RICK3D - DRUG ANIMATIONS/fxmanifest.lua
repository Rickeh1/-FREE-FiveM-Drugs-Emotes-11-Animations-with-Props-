fx_version "cerulean"
game "gta5"

lua54 "yes"
use_experimental_fxv2_oal "yes"

author "Rick"
version "1.0.0"

escrow_ignore{
    "configs/**",
}

data_file 'DLC_ITYP_REQUEST' 'stream/rick_lightervile.ytyp'